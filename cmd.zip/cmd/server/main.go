package main

import (
	"context"
 	greetv1 "github.com/abitofhelp/bazel-go-googleapis/gen/greet/v1"
 	"google.golang.org/protobuf/types/known/timestamppb"
	"go.uber.org/zap"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
	"log"
	"net"
)

const (
	port = ":50051"
)

// server is used to implement helloworld.GreeterServer.
type server struct{}

// SayHello implements helloworld.GreeterServer

func (s *server) SayHello(ctx context.Context, in *pb.HelloRequest) (*pb.HelloReply, error) {
	return &pb.HelloReply{Message: "Hello " + in.Name}, nil
}
func main() {
	logger, _ := zap.NewProduction()
	defer logger.Sync()
	lis, err := net.Listen("tcp", port)
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}
	s := grpc.NewServer()
	pb.RegisterGreeterServer(s, &server{})
	// Register reflection service on gRPC server.
	reflection.Register(s)
	if err := s.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}


func main() {
	// greeter := &GreetServer{}
	// mux := http.NewServeMux()
	// path, handler := greetv1connect.NewGreetServiceHandler(greeter)
	// mux.Handle(path, handler)

	// checker := grpchealth.NewStaticChecker(
	// 	greetv1connect.GreetServiceName,
	// )
	// mux.Handle(grpchealth.NewHandler(checker))

	// reflector := grpcreflect.NewStaticReflector(greetv1connect.GreetServiceName)
	// mux.Handle(grpcreflect.NewHandlerV1(reflector))
	// mux.Handle(grpcreflect.NewHandlerV1Alpha(reflector))

	// // If you don't need to support HTTP/2 without TLS (h2c), you can drop
	// // x/net/http2 and use http.ListenAndServeTLS instead.
	// err := http.ListenAndServe(
	// 	"localhost:8080",
	// 	// Use h2c so we can serve HTTP/2 without TLS.
	// 	h2c.NewHandler(mux, &http2.Server{}),
	// )
	// if err != nil {
	// 	panic(err)
	// }
}
